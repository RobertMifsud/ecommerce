<footer class="footer text-center">
	<img class="margin-top-25 margin-bottom-25" src="img/logo.png" alt="The Plant House">
</footer>
