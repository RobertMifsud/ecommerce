
<ul class="nav nav-pills nav-stacked nav-categories">
    <li class="active"><a href="#">CMS</a></li>     
    <li><a href="#">Add product</a></li>
    <li><a href="#">Edit product</a></li>
    <li><a href="#">Manage Categories</a></li>
    <li><a href="#">User Managment</a></li>
</ul>

